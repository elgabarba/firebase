class BDConf {
  String connectionString = "mongodb+srv://jheremyvalda:Soporte%40@cluster0.qkqyp4t.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
}                            